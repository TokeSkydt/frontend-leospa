module.exports = {
  theme: {
    extend: {
      fontFamily: {
        themify: ['themify', 'sans-serif'],
      },
    },
  },
  plugins: [],
};