export type AppointmentData = {
  _id?: string;
  name: string;
  email: string;
  phone: string;
  treatment: string;    // treatment ID som string
  dateandtime: string;  // ISO 8601 string
  notes: string;
  __v?: number;
};

// Hent alle aftaler (fx til admin-side)
export async function getAppointmentData(): Promise<AppointmentData[]> {
  const res = await fetch('http://localhost:5029/appointment/admin');
  if (!res.ok) {
    throw new Error('Failed to fetch appointments');
  }
  return res.json();
}

export async function postAppointment(appointment: AppointmentData) {
  const formData = new FormData();
  formData.append("name", appointment.name);
  formData.append("email", appointment.email);
  formData.append("phone", appointment.phone);
  formData.append("date", appointment.dateandtime.split('T')[0]);
  formData.append("time", appointment.dateandtime.split('T')[1].substring(0, 5));
  formData.append("notes", appointment.notes ?? "");
  formData.append("treatment", appointment.treatment);

  const res = await fetch("http://localhost:5029/appointment", {
    method: "POST",
    body: formData, // 👈 FormData goes here
  });

  if (!res.ok) {
    throw new Error(`Failed to create appointment: ${res.statusText}`);
  }

  return res.json();
};
