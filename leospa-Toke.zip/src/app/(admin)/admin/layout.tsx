// app/admin/layout.tsx
import "../../globals.css";
import AdminSidebar from "@/components/AdminSidebar";

export const metadata = {
  title: "Admin Panel",
  description: "Admin dashboard",
};

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-gray-100">
        {/* Du kan tilføje en admin-topbar her, hvis du vil */}
        <AdminSidebar />
        {children}

      </body>
    </html>
  );
}
