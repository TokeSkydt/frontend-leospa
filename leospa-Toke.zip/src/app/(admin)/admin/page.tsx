import React from 'react'

function hej() {
  return (
    <div>hej</div>
  )
}

export default hej